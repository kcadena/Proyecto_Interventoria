--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.4
-- Dumped by pg_dump version 9.6.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.repositorios_usuarios DROP CONSTRAINT repositorios_usuarios_id_usuario_fkey;
ALTER TABLE ONLY public.recursos DROP CONSTRAINT recursos_keym_fkey;
ALTER TABLE ONLY public.recursos DROP CONSTRAINT recursos_id_usuario_fkey;
ALTER TABLE ONLY public.proyectos DROP CONSTRAINT proyectos_keym_fkey;
ALTER TABLE ONLY public.proyectos DROP CONSTRAINT proyectos_id_usuario_fkey;
ALTER TABLE ONLY public.presupuesto DROP CONSTRAINT presupuesto_keym_fkey;
ALTER TABLE ONLY public.presupuesto DROP CONSTRAINT presupuesto_id_usuario_fkey;
ALTER TABLE ONLY public.marcador DROP CONSTRAINT marcador_fk2;
ALTER TABLE ONLY public.marcador DROP CONSTRAINT marcador_fk;
ALTER TABLE ONLY public.categorias_mapa DROP CONSTRAINT fkey_caracteristicas;
ALTER TABLE ONLY public.costos DROP CONSTRAINT costos_keym_fkey;
ALTER TABLE ONLY public.costos DROP CONSTRAINT costos_id_usuario_fkey;
ALTER TABLE ONLY public.caracteristicas DROP CONSTRAINT caracteristicas_usuario_asignado_fkey;
ALTER TABLE ONLY public.caracteristicas DROP CONSTRAINT caracteristicas_keym_fkey;
ALTER TABLE ONLY public.caracteristicas DROP CONSTRAINT caracteristicas_id_usuario_fkey;
ALTER TABLE ONLY public.archivos DROP CONSTRAINT archivos_keym_fkey;
ALTER TABLE ONLY public.actividades DROP CONSTRAINT actividades_keym_fkey;
ALTER TABLE ONLY public.actividades DROP CONSTRAINT actividades_id_usuario_fkey;
DROP INDEX public.caracteristicas_keym_id_usuario_id_caracteristica_key;
ALTER TABLE ONLY public.usuarios DROP CONSTRAINT usuarios_pkey;
ALTER TABLE ONLY public.repositorios_usuarios DROP CONSTRAINT repositorios_usuarios_pkey;
ALTER TABLE ONLY public.recursos DROP CONSTRAINT recursos_pkey;
ALTER TABLE ONLY public.presupuesto DROP CONSTRAINT presupuesto_pkey;
ALTER TABLE ONLY public.proyectos DROP CONSTRAINT pkey_prj;
ALTER TABLE ONLY public.table_sequence DROP CONSTRAINT pk_ts;
ALTER TABLE ONLY public.marcador DROP CONSTRAINT marcador_pkey;
ALTER TABLE ONLY public.costos DROP CONSTRAINT costos_pkey;
ALTER TABLE ONLY public.configuracion_inicial DROP CONSTRAINT configuracion_inicial_pkey;
ALTER TABLE ONLY public.categorias_mapa DROP CONSTRAINT categorias_mapa_pkey;
ALTER TABLE ONLY public.caracteristicas DROP CONSTRAINT caracteristicas_pkey;
ALTER TABLE ONLY public.archivos DROP CONSTRAINT archivos_pkey;
ALTER TABLE ONLY public.actividades DROP CONSTRAINT actividades_pkey;
ALTER TABLE public.marcador ALTER COLUMN id_marcador DROP DEFAULT;
DROP TABLE public.usuarios;
DROP SEQUENCE public.usuario_id_usuario;
DROP TABLE public.table_sequence;
DROP TABLE public.repositorios_usuarios;
DROP TABLE public.recursos;
DROP TABLE public.proyectos;
DROP TABLE public.presupuesto;
DROP SEQUENCE public.marcador_id_marcador_seq;
DROP TABLE public.marcador;
DROP TABLE public.costos;
DROP TABLE public.configuracion_inicial;
DROP TABLE public.categorias_mapa;
DROP SEQUENCE public.sequence_category;
DROP TABLE public.caracteristicas;
DROP TABLE public.archivos;
DROP TABLE public.actividades;
DROP FUNCTION public.func(keyml bigint, id_caracteristical bigint, id_usuariol bigint, por numeric, cump numeric, keymp bigint, id_caracteristicap bigint, id_usuariop bigint);
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: func(bigint, bigint, bigint, numeric, numeric, bigint, bigint, bigint); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION func(keyml bigint, id_caracteristical bigint, id_usuariol bigint, por numeric, cump numeric, keymp bigint, id_caracteristicap bigint, id_usuariop bigint) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
	val numeric(5,2) := 0;
	val1 numeric(5,2):=0;
	 pl        record;
BEGIN

   if ((select count(c.id_caracteristica) from caracteristicas c where c.keym_padre = keyml and c.id_caracteristica = id_caracteristical and c.id_usuario = id_usuariol) > 0) 
   then
  val := 0;
  for pl in (select  *  from caracteristicas c where c.keym_padre = keyml and c.id_caracteristica = id_caracteristical and c.id_usuario = id_usuariol) 
  loop
	
	select func(pl.keym,pl.id_caracteristica,pl.id_usuario,pl.porcentaje,pl.porcentaje_cumplido,keymp,id_caracteristicap,id_usuariop) into val1;
	val := val+val1;
	raise notice 'Value: %', val;
	
  end loop;

if(keymp != keyml and id_caracteristicap != id_caracteristical and id_usuariop != id_usuariol) 
then

  val := val + cump; 
  val := por * val/100;
  raise notice 'Value 2: %', val;
else 
val := val + cump;
end if;
return val;
else
	
	return por * (cump/100);
end if;
   
return 0;
END;
$$;


ALTER FUNCTION public.func(keyml bigint, id_caracteristical bigint, id_usuariol bigint, por numeric, cump numeric, keymp bigint, id_caracteristicap bigint, id_usuariop bigint) OWNER TO postgres;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: actividades; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE actividades (
    keym bigint NOT NULL,
    id_actividad bigint NOT NULL,
    id_usuario bigint NOT NULL,
    keym_car bigint NOT NULL,
    id_usuario_car bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    nombre character varying NOT NULL,
    descripcion character varying NOT NULL,
    pos integer NOT NULL,
    folder integer NOT NULL,
    fecha_ultima_modificacion character varying
);


ALTER TABLE actividades OWNER TO postgres;

--
-- Name: archivos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE archivos (
    keym_arc bigint NOT NULL,
    id_archivo bigint NOT NULL,
    id_usuario_arc bigint NOT NULL,
    keym_car bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    id_usuario_car bigint NOT NULL,
    nombre_archivo character varying NOT NULL,
    titulo character varying,
    subtitulo character varying,
    descripcion character varying,
    contenido text,
    fecha_creacion character varying NOT NULL,
    fecha_ultima_modificacion character varying NOT NULL,
    publicacion integer,
    tipo character varying,
    localizacion numeric(20,16),
    longitud numeric(20,16),
    "srcGifServ" character varying,
    "srcServ" character varying,
    visible_map boolean DEFAULT false
);


ALTER TABLE archivos OWNER TO postgres;

--
-- Name: caracteristicas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE caracteristicas (
    keym bigint NOT NULL,
    id_usuario bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    keym_padre bigint,
    id_usuario_padre bigint,
    id_caracteristica_padre bigint,
    estado character varying NOT NULL,
    porcentaje_asignado numeric(5,2) DEFAULT 0 NOT NULL,
    porcentaje_cumplido numeric(5,2) DEFAULT 0 NOT NULL,
    recursos integer,
    recursos_restantes integer,
    presupuesto integer,
    costos integer,
    tipo_caracteristica character(1) NOT NULL,
    visualizar_superior boolean NOT NULL,
    usuario_asignado bigint,
    publicacion_web boolean DEFAULT false,
    porcentaje numeric(5,2),
    fecha_inicio character varying,
    fecha_fin character varying,
    fecha_ultima_modificacion character varying,
    publicacion_reporte boolean DEFAULT false NOT NULL
);


ALTER TABLE caracteristicas OWNER TO postgres;

--
-- Name: sequence_category; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE sequence_category
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE;


ALTER TABLE sequence_category OWNER TO postgres;

--
-- Name: categorias_mapa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE categorias_mapa (
    id_categoria smallint DEFAULT nextval('sequence_category'::regclass) NOT NULL,
    nombre character varying,
    color character varying(30),
    keym_car bigint,
    id_caracteristica bigint,
    id_usuario_car bigint
);


ALTER TABLE categorias_mapa OWNER TO postgres;

--
-- Name: configuracion_inicial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE configuracion_inicial (
    id integer NOT NULL,
    configuracion character varying NOT NULL,
    val_configuracion character varying NOT NULL,
    descripcion character varying
);


ALTER TABLE configuracion_inicial OWNER TO postgres;

--
-- Name: costos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE costos (
    keym bigint NOT NULL,
    id_usuario bigint NOT NULL,
    id_costo bigint NOT NULL,
    keym_car bigint NOT NULL,
    id_usuario_car bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    nombre character varying NOT NULL,
    cantidad integer NOT NULL,
    valor integer NOT NULL
);


ALTER TABLE costos OWNER TO postgres;

--
-- Name: marcador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE marcador (
    keym bigint,
    id_caracteristica bigint,
    id_usuario bigint,
    id_marcador integer NOT NULL,
    id_categoria smallint,
    etiqueta character varying(200),
    latitud numeric(30,20),
    longitud numeric(30,20)
);


ALTER TABLE marcador OWNER TO postgres;

--
-- Name: marcador_id_marcador_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE marcador_id_marcador_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE marcador_id_marcador_seq OWNER TO postgres;

--
-- Name: marcador_id_marcador_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE marcador_id_marcador_seq OWNED BY marcador.id_marcador;


--
-- Name: presupuesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE presupuesto (
    keym bigint NOT NULL,
    id_presupuesto bigint NOT NULL,
    id_usuario bigint NOT NULL,
    keym_car bigint NOT NULL,
    id_usuario_car bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    nombre character varying NOT NULL,
    cantidad integer NOT NULL,
    valor integer NOT NULL
);


ALTER TABLE presupuesto OWNER TO postgres;

--
-- Name: proyectos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE proyectos (
    keym bigint NOT NULL,
    id_proyecto bigint NOT NULL,
    id_usuario bigint NOT NULL,
    keym_car bigint NOT NULL,
    id_usuario_car bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    nombre character varying,
    plantilla character varying NOT NULL,
    ir_proyecto boolean NOT NULL,
    icon character varying,
    descripcion character varying NOT NULL,
    contador integer,
    fecha_ultima_modificacion character varying
);


ALTER TABLE proyectos OWNER TO postgres;

--
-- Name: recursos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE recursos (
    keym bigint NOT NULL,
    id_recurso bigint NOT NULL,
    id_usuario bigint NOT NULL,
    keym_car bigint NOT NULL,
    id_usuario_car bigint NOT NULL,
    id_caracteristica bigint NOT NULL,
    nombre_recurso character varying NOT NULL,
    cantidad integer DEFAULT 1 NOT NULL
);


ALTER TABLE recursos OWNER TO postgres;

--
-- Name: repositorios_usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE repositorios_usuarios (
    id_usuario bigint NOT NULL,
    ruta_repositorio character varying NOT NULL
);


ALTER TABLE repositorios_usuarios OWNER TO postgres;

--
-- Name: table_sequence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE table_sequence (
    actividades bigint DEFAULT 0 NOT NULL,
    archivos bigint DEFAULT 0 NOT NULL,
    caracteristicas bigint DEFAULT 0 NOT NULL,
    costos bigint DEFAULT 0 NOT NULL,
    proyectos bigint DEFAULT 0 NOT NULL,
    proyectos_meta_datos bigint DEFAULT 0 NOT NULL,
    recursos bigint DEFAULT 0 NOT NULL,
    presuspuesto bigint DEFAULT 0 NOT NULL,
    key bigint DEFAULT 0 NOT NULL
);


ALTER TABLE table_sequence OWNER TO postgres;

--
-- Name: usuario_id_usuario; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usuario_id_usuario
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usuario_id_usuario OWNER TO postgres;

--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usuarios (
    id_usuario bigint DEFAULT nextval('usuario_id_usuario'::regclass) NOT NULL,
    pass character varying,
    administrador boolean DEFAULT false,
    e_mail character varying,
    nombre character varying,
    apellido character varying,
    genero character(1),
    cargo character varying,
    telefono character varying,
    entidad character varying,
    imagen character varying,
    disponible boolean DEFAULT false
);


ALTER TABLE usuarios OWNER TO postgres;

--
-- Name: marcador id_marcador; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY marcador ALTER COLUMN id_marcador SET DEFAULT nextval('marcador_id_marcador_seq'::regclass);


--
-- Data for Name: actividades; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY actividades (keym, id_actividad, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre, descripcion, pos, folder, fecha_ultima_modificacion) FROM stdin;
\.
COPY actividades (keym, id_actividad, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre, descripcion, pos, folder, fecha_ultima_modificacion) FROM '$$PATH$$/2252.dat';

--
-- Data for Name: archivos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY archivos (keym_arc, id_archivo, id_usuario_arc, keym_car, id_caracteristica, id_usuario_car, nombre_archivo, titulo, subtitulo, descripcion, contenido, fecha_creacion, fecha_ultima_modificacion, publicacion, tipo, localizacion, longitud, "srcGifServ", "srcServ", visible_map) FROM stdin;
\.
COPY archivos (keym_arc, id_archivo, id_usuario_arc, keym_car, id_caracteristica, id_usuario_car, nombre_archivo, titulo, subtitulo, descripcion, contenido, fecha_creacion, fecha_ultima_modificacion, publicacion, tipo, localizacion, longitud, "srcGifServ", "srcServ", visible_map) FROM '$$PATH$$/2253.dat';

--
-- Data for Name: caracteristicas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY caracteristicas (keym, id_usuario, id_caracteristica, keym_padre, id_usuario_padre, id_caracteristica_padre, estado, porcentaje_asignado, porcentaje_cumplido, recursos, recursos_restantes, presupuesto, costos, tipo_caracteristica, visualizar_superior, usuario_asignado, publicacion_web, porcentaje, fecha_inicio, fecha_fin, fecha_ultima_modificacion, publicacion_reporte) FROM stdin;
\.
COPY caracteristicas (keym, id_usuario, id_caracteristica, keym_padre, id_usuario_padre, id_caracteristica_padre, estado, porcentaje_asignado, porcentaje_cumplido, recursos, recursos_restantes, presupuesto, costos, tipo_caracteristica, visualizar_superior, usuario_asignado, publicacion_web, porcentaje, fecha_inicio, fecha_fin, fecha_ultima_modificacion, publicacion_reporte) FROM '$$PATH$$/2254.dat';

--
-- Data for Name: categorias_mapa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY categorias_mapa (id_categoria, nombre, color, keym_car, id_caracteristica, id_usuario_car) FROM stdin;
\.
COPY categorias_mapa (id_categoria, nombre, color, keym_car, id_caracteristica, id_usuario_car) FROM '$$PATH$$/2256.dat';

--
-- Data for Name: configuracion_inicial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY configuracion_inicial (id, configuracion, val_configuracion, descripcion) FROM stdin;
\.
COPY configuracion_inicial (id, configuracion, val_configuracion, descripcion) FROM '$$PATH$$/2257.dat';

--
-- Data for Name: costos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY costos (keym, id_usuario, id_costo, keym_car, id_usuario_car, id_caracteristica, nombre, cantidad, valor) FROM stdin;
\.
COPY costos (keym, id_usuario, id_costo, keym_car, id_usuario_car, id_caracteristica, nombre, cantidad, valor) FROM '$$PATH$$/2258.dat';

--
-- Data for Name: marcador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY marcador (keym, id_caracteristica, id_usuario, id_marcador, id_categoria, etiqueta, latitud, longitud) FROM stdin;
\.
COPY marcador (keym, id_caracteristica, id_usuario, id_marcador, id_categoria, etiqueta, latitud, longitud) FROM '$$PATH$$/2259.dat';

--
-- Name: marcador_id_marcador_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('marcador_id_marcador_seq', 75, true);


--
-- Data for Name: presupuesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY presupuesto (keym, id_presupuesto, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre, cantidad, valor) FROM stdin;
\.
COPY presupuesto (keym, id_presupuesto, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre, cantidad, valor) FROM '$$PATH$$/2261.dat';

--
-- Data for Name: proyectos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY proyectos (keym, id_proyecto, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre, plantilla, ir_proyecto, icon, descripcion, contador, fecha_ultima_modificacion) FROM stdin;
\.
COPY proyectos (keym, id_proyecto, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre, plantilla, ir_proyecto, icon, descripcion, contador, fecha_ultima_modificacion) FROM '$$PATH$$/2262.dat';

--
-- Data for Name: recursos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY recursos (keym, id_recurso, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre_recurso, cantidad) FROM stdin;
\.
COPY recursos (keym, id_recurso, id_usuario, keym_car, id_usuario_car, id_caracteristica, nombre_recurso, cantidad) FROM '$$PATH$$/2263.dat';

--
-- Data for Name: repositorios_usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY repositorios_usuarios (id_usuario, ruta_repositorio) FROM stdin;
\.
COPY repositorios_usuarios (id_usuario, ruta_repositorio) FROM '$$PATH$$/2264.dat';

--
-- Name: sequence_category; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('sequence_category', 22, true);


--
-- Data for Name: table_sequence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY table_sequence (actividades, archivos, caracteristicas, costos, proyectos, proyectos_meta_datos, recursos, presuspuesto, key) FROM stdin;
\.
COPY table_sequence (actividades, archivos, caracteristicas, costos, proyectos, proyectos_meta_datos, recursos, presuspuesto, key) FROM '$$PATH$$/2265.dat';

--
-- Name: usuario_id_usuario; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usuario_id_usuario', 122, true);


--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usuarios (id_usuario, pass, administrador, e_mail, nombre, apellido, genero, cargo, telefono, entidad, imagen, disponible) FROM stdin;
\.
COPY usuarios (id_usuario, pass, administrador, e_mail, nombre, apellido, genero, cargo, telefono, entidad, imagen, disponible) FROM '$$PATH$$/2267.dat';

--
-- Name: actividades actividades_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actividades
    ADD CONSTRAINT actividades_pkey PRIMARY KEY (keym, id_actividad, id_usuario);


--
-- Name: archivos archivos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY archivos
    ADD CONSTRAINT archivos_pkey PRIMARY KEY (keym_arc, id_archivo, id_usuario_arc);


--
-- Name: caracteristicas caracteristicas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY caracteristicas
    ADD CONSTRAINT caracteristicas_pkey PRIMARY KEY (keym, id_caracteristica, id_usuario);


--
-- Name: categorias_mapa categorias_mapa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categorias_mapa
    ADD CONSTRAINT categorias_mapa_pkey PRIMARY KEY (id_categoria);


--
-- Name: configuracion_inicial configuracion_inicial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY configuracion_inicial
    ADD CONSTRAINT configuracion_inicial_pkey PRIMARY KEY (id);


--
-- Name: costos costos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY costos
    ADD CONSTRAINT costos_pkey PRIMARY KEY (keym, id_costo, id_usuario);


--
-- Name: marcador marcador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY marcador
    ADD CONSTRAINT marcador_pkey PRIMARY KEY (id_marcador);


--
-- Name: table_sequence pk_ts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY table_sequence
    ADD CONSTRAINT pk_ts PRIMARY KEY (key);


--
-- Name: proyectos pkey_prj; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proyectos
    ADD CONSTRAINT pkey_prj PRIMARY KEY (keym, id_proyecto, id_usuario);


--
-- Name: presupuesto presupuesto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY presupuesto
    ADD CONSTRAINT presupuesto_pkey PRIMARY KEY (keym, id_presupuesto, id_usuario);


--
-- Name: recursos recursos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY recursos
    ADD CONSTRAINT recursos_pkey PRIMARY KEY (keym, id_recurso, id_usuario);


--
-- Name: repositorios_usuarios repositorios_usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY repositorios_usuarios
    ADD CONSTRAINT repositorios_usuarios_pkey PRIMARY KEY (id_usuario);


--
-- Name: usuarios usuarios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usuarios
    ADD CONSTRAINT usuarios_pkey PRIMARY KEY (id_usuario);


--
-- Name: caracteristicas_keym_id_usuario_id_caracteristica_key; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX caracteristicas_keym_id_usuario_id_caracteristica_key ON caracteristicas USING btree (keym, id_usuario, id_caracteristica);


--
-- Name: actividades actividades_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actividades
    ADD CONSTRAINT actividades_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- Name: actividades actividades_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY actividades
    ADD CONSTRAINT actividades_keym_fkey FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: archivos archivos_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY archivos
    ADD CONSTRAINT archivos_keym_fkey FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: caracteristicas caracteristicas_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY caracteristicas
    ADD CONSTRAINT caracteristicas_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- Name: caracteristicas caracteristicas_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY caracteristicas
    ADD CONSTRAINT caracteristicas_keym_fkey FOREIGN KEY (keym_padre, id_caracteristica_padre, id_usuario_padre) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: caracteristicas caracteristicas_usuario_asignado_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY caracteristicas
    ADD CONSTRAINT caracteristicas_usuario_asignado_fkey FOREIGN KEY (usuario_asignado) REFERENCES usuarios(id_usuario);


--
-- Name: costos costos_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY costos
    ADD CONSTRAINT costos_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- Name: costos costos_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY costos
    ADD CONSTRAINT costos_keym_fkey FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: categorias_mapa fkey_caracteristicas; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY categorias_mapa
    ADD CONSTRAINT fkey_caracteristicas FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: marcador marcador_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY marcador
    ADD CONSTRAINT marcador_fk FOREIGN KEY (id_categoria) REFERENCES categorias_mapa(id_categoria) MATCH FULL;


--
-- Name: marcador marcador_fk2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY marcador
    ADD CONSTRAINT marcador_fk2 FOREIGN KEY (keym, id_caracteristica, id_usuario) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: presupuesto presupuesto_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY presupuesto
    ADD CONSTRAINT presupuesto_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- Name: presupuesto presupuesto_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY presupuesto
    ADD CONSTRAINT presupuesto_keym_fkey FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: proyectos proyectos_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proyectos
    ADD CONSTRAINT proyectos_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- Name: proyectos proyectos_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY proyectos
    ADD CONSTRAINT proyectos_keym_fkey FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: recursos recursos_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY recursos
    ADD CONSTRAINT recursos_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- Name: recursos recursos_keym_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY recursos
    ADD CONSTRAINT recursos_keym_fkey FOREIGN KEY (keym_car, id_caracteristica, id_usuario_car) REFERENCES caracteristicas(keym, id_caracteristica, id_usuario);


--
-- Name: repositorios_usuarios repositorios_usuarios_id_usuario_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY repositorios_usuarios
    ADD CONSTRAINT repositorios_usuarios_id_usuario_fkey FOREIGN KEY (id_usuario) REFERENCES usuarios(id_usuario);


--
-- PostgreSQL database dump complete
--

